/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_escolar1;

/**
 *
 * @author marca
 */
public class Sistema_Escolar1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
