/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_escolar1.personas;

/**
 *
 * @author marca
 */
public class Profesor extends Person {
    private String especialidad;
    private String grupo;

    public Profesor(String nombre, int edad, String especialidad, String grupo) {
        super(nombre, edad);
        this.especialidad = especialidad;
        this.grupo = grupo;
    }

    @Override
    public void yourself() {
        super.yourself();
        System.out.println("Soy profesor de " + especialidad + " y enseño al grupo " + grupo + ".");
    }
}

    

