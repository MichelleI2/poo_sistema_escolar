/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_escolar1.personas;

/**
 *
 * @author marca
 */
public class Principal {
    public static void main(String[] args) {
        Person persona = new Person("Carlos", 40);
        persona.yourself();
        System.out.println();

        Estudiante estudiante = new Estudiante("Ana", 20, "A012345", "Ingeniería en Computación");
        estudiante.yourself();
        System.out.println();

        Profesor profesor = new Profesor("María", 35, "Matemáticas", "3A");
        profesor.yourself();
    }
}

    

