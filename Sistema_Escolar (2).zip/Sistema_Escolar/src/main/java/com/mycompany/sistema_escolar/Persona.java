/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_escolar;

import java.util.Scanner;

/**
 *
 * @author muche
 */
public class Persona {
    // Atributos
    Scanner sc = new Scanner(System.in);
    public String nombre;
    public int edad;

    // Constructor
    public Persona () {
        this.nombre = nombre;
        this.edad = edad;
    }

    // Método para presentarse
    public void Yourself() {
        System.out.println("Nombre:");
        nombre=sc.next();
        System.out.println("Edad:");
        edad=sc.nextInt();
        System.out.println("Hola, mi nombre es " + nombre + " y tengo " + edad + " años.");
        
    }

    // Métodos getter y setter (opcional)
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
}

