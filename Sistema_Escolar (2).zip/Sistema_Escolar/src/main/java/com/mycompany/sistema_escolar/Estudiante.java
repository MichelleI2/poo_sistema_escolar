/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_escolar;


/**
 *
 * @author muche
 */
public class Estudiante extends Persona{
    
    //Atributos 
    private int matricula;
    private String carrera;

    public Estudiante() {
        this.matricula = matricula;
        this.carrera = carrera;
    }
    
    public void datosalumno(){
        System.out.println("Matricula:");
        matricula=sc.nextInt();
        System.out.println("Carrera cursada:");
        carrera=sc.next();
        this.matricula=matricula;
        this.carrera=carrera;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    //Métodos getter y setter de Persona
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
