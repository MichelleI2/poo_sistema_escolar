/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_escolar;

/**
 *
 * @author muche
 */
public class Sistema_Escolar {

//no entendi nada :)
    public static void main(String[] args) {
       
       Persona alu1 = new Persona();
       Estudiante alu2 = new Estudiante();
       Profesor alu3 = new Profesor ();
       
       alu1.Yourself();
       
       alu2.datosalumno();
       alu3.datosprofesor();
        
    }
}
