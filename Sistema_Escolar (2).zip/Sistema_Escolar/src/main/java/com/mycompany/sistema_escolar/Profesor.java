/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_escolar;

/**
 *
 * @author muche
 */
public class Profesor extends Persona{
    private String especialidad;
    private int grupo;

    public Profesor() {
        this.especialidad=especialidad;
        this.grupo=grupo;
    }
    
    
public void datosprofesor (){
    System.out.println("Especialidad:");
        especialidad=sc.next();
        System.out.println("Grupo asignado:");
        grupo=sc.nextInt();
        this.especialidad=especialidad;
        this.grupo=grupo;
}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getGrupo() {
        return grupo;
    }

    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }

    
}
